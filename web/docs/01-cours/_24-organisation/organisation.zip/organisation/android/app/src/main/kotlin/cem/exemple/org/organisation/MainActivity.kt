package cem.exemple.org.organisation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
