class Cat {

  Cat({required this.id, required this.name, required this.image, required, required this.description});

  int id;
  String name;
  String image;
  String description;

}