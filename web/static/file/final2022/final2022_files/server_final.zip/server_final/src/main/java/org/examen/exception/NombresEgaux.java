package org.examen.exception;

public class NombresEgaux extends Exception {
}
