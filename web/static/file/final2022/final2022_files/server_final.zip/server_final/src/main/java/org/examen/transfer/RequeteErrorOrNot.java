package org.examen.transfer;

import java.util.Date;

public class RequeteErrorOrNot {

    public String nom;

}
