package org.examen.transfer;

public class RequetePlusGrand {
    public int val1;
    public int val2;
}
