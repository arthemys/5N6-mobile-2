
import 'package:flutter/material.dart';

class FinalPage extends StatefulWidget {
  const FinalPage({super.key,});

  @override
  State<FinalPage> createState() => _FinalPageState();
}

class _FinalPageState extends State<FinalPage> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
        title: Text("Final Firestore"),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          const Text(
            'Examen examen, à toi de jouer',
          ),
        ],
      ),
    );
  }
}
