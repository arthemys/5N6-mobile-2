import 'package:final_a23/final.dart';
import 'package:final_a23/firebase_options.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(FinalApp());
}

class FinalApp extends StatelessWidget {
  const FinalApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Final Firestore',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const FinalPage(),
    );
  }
}
